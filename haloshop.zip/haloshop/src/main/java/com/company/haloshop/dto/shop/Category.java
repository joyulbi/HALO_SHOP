package com.company.haloshop.dto.shop;

import lombok.Data;

@Data
public class Category {
    private Long id;
    private String name;
}
