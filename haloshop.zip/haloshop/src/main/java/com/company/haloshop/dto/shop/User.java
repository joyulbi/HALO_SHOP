package com.company.haloshop.dto.shop;

public class User {

}
