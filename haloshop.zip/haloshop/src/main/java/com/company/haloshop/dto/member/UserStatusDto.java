package com.company.haloshop.dto.member;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserStatusDto {
    private Integer id;
    private Integer status;
}
