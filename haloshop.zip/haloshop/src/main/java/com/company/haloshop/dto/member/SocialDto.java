package com.company.haloshop.dto.member;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SocialDto {
    private Integer id;
    private String socialType;
}
