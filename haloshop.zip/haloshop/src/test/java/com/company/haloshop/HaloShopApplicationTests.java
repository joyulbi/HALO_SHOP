package com.company.haloshop;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaloShopApplicationTests {
	   @Test
	    void contextLoads() {
	        //테스트용 지워버려도됨
	    }
	
}
